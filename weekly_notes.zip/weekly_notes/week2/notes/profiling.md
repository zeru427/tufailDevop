# Profiling

The means of dynamically watching/analyzing a running program to track metrics or measure information about its performance. Often times, tracking method calls and durations as well as memory/cpu usage at least. Could additionally track number of objects created or Garbage Collector activity.

We will be using JProfiler later in the training. Which has a trial period. But in general, is a paid tool.